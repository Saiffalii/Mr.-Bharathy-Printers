import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Phone, MessageCircle, Mail, MapPin, Star, Printer, Package, Truck, Shield } from "lucide-react";
import Image from "next/image";

export default function HomePage() {
  const whatsappNumber = "918248481143";
  const whatsappMessage = encodeURIComponent("Hello! I'm interested in your printing services. Can you help me?");
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

  return (
    <div className="min-h-screen">
      {/* Navigation Header */}
      <nav className="fixed top-0 w-full z-50 bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                <Printer className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Mr. Bharathy Printers</h1>
                <p className="text-xs text-blue-200">Professional Printing Services</p>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-6">
              <a href="#home" className="text-white hover:text-blue-300 transition-colors">Home</a>
              <a href="#about" className="text-white hover:text-blue-300 transition-colors">About</a>
              <a href="#products" className="text-white hover:text-blue-300 transition-colors">Products</a>
              <a href="#testimonials" className="text-white hover:text-blue-300 transition-colors">Reviews</a>
              <a href="#contact" className="text-white hover:text-blue-300 transition-colors">Contact</a>
            </div>
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button className="whatsapp-btn text-white font-semibold">
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp
              </Button>
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="gradient-hero min-h-screen flex items-center justify-center pt-20">
        <div className="container mx-auto px-4 text-center">
          <div className="animate-fade-in">
            <Badge className="mb-6 bg-blue-500/20 text-blue-200 border-blue-400/30">
              Trusted by 1000+ Customers Across India
            </Badge>
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              High-Quality Printing.
              <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                {" "}Affordable Prices.
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Premium print products for religious, personal, and professional use.
              Delivered across India with guaranteed quality.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="whatsapp-btn text-white font-semibold px-8 py-6 text-lg">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Order on WhatsApp
                </Button>
              </a>
              <a href="#products">
                <Button size="lg" variant="outline" className="border-blue-400 text-blue-300 hover:bg-blue-500/20 px-8 py-6 text-lg">
                  View Products
                </Button>
              </a>
            </div>
          </div>

          {/* Floating Product Images */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
            <div className="animate-float">
              <img
                src="https://ext.same-assets.com/2358184486/3717697990.jpeg"
                alt="Viboodhi Cover"
                className="w-full h-32 object-cover rounded-lg shadow-2xl glow-blue"
              />
            </div>
            <div className="animate-float" style={{animationDelay: '1s'}}>
              <img
                src="https://ext.same-assets.com/2358184486/784078873.jpeg"
                alt="Visiting Cards"
                className="w-full h-32 object-cover rounded-lg shadow-2xl glow-blue"
              />
            </div>
            <div className="animate-float" style={{animationDelay: '2s'}}>
              <img
                src="https://ext.same-assets.com/2358184486/554750456.jpeg"
                alt="Business Cards"
                className="w-full h-32 object-cover rounded-lg shadow-2xl glow-blue"
              />
            </div>
            <div className="animate-float" style={{animationDelay: '3s'}}>
              <img
                src="https://ext.same-assets.com/2358184486/1475995303.jpeg"
                alt="Flyers"
                className="w-full h-32 object-cover rounded-lg shadow-2xl glow-blue"
              />
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="gradient-section py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 animate-slide-up">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              About <span className="text-blue-400">Mr. Bharathy Printers</span>
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Trusted printing experts offering premium print products for religious, personal, and professional use.
              We pride ourselves on delivering high-quality printing solutions at affordable prices,
              with shipping across India.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <Card className="gradient-card border-slate-600 text-center">
              <CardHeader>
                <Printer className="w-12 h-12 text-blue-400 mx-auto mb-4" />
                <CardTitle className="text-white">Premium Quality</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300">State-of-the-art printing technology for superior results</p>
              </CardContent>
            </Card>

            <Card className="gradient-card border-slate-600 text-center">
              <CardHeader>
                <Package className="w-12 h-12 text-blue-400 mx-auto mb-4" />
                <CardTitle className="text-white">Wide Range</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300">From religious covers to business cards and promotional materials</p>
              </CardContent>
            </Card>

            <Card className="gradient-card border-slate-600 text-center">
              <CardHeader>
                <Truck className="w-12 h-12 text-blue-400 mx-auto mb-4" />
                <CardTitle className="text-white">Pan-India Delivery</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300">Fast and reliable shipping to every corner of India</p>
              </CardContent>
            </Card>

            <Card className="gradient-card border-slate-600 text-center">
              <CardHeader>
                <Shield className="w-12 h-12 text-blue-400 mx-auto mb-4" />
                <CardTitle className="text-white">Quality Guarantee</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300">100% satisfaction guarantee on all our printing services</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-20 bg-gradient-to-b from-slate-900 to-black">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Our <span className="text-blue-400">Products & Services</span>
            </h2>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Explore our comprehensive range of printing solutions designed to meet all your needs
            </p>
          </div>

          {/* Viboodhi Covers */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold text-white mb-8 text-center">
              Viboodhi Covers <Badge className="bg-orange-500 text-white ml-2">@ Rs. 199/-</Badge>
            </h3>
            <div className="grid md:grid-cols-4 gap-6">
              {[
                { name: "Perumal Viboodhi Cover 7", image: "https://ext.same-assets.com/2358184486/3717697990.jpeg" },
                { name: "Perumal Viboodhi Cover 6", image: "https://ext.same-assets.com/2358184486/293873589.jpeg" },
                { name: "Perumal Viboodhi Cover 5", image: "https://ext.same-assets.com/2358184486/3349309083.jpeg" },
                { name: "Shivan Viboodhi Cover 5", image: "https://ext.same-assets.com/2358184486/554750456.jpeg" }
              ].map((product) => (
                <Card key={product.name} className="gradient-card border-slate-600 overflow-hidden group hover:scale-105 transition-transform duration-300">
                  <div className="relative h-48">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                  </div>
                  <CardHeader>
                    <CardTitle className="text-white text-sm">{product.name}</CardTitle>
                    <CardDescription className="text-blue-300 font-semibold">From Rs. 199.00</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                      <Button className="whatsapp-btn w-full text-white">
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Buy on WhatsApp
                      </Button>
                    </a>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Visiting Cards */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold text-white mb-8 text-center">
              Budget-Friendly Visiting Cards
            </h3>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                { name: "Economy Gloss Visiting Card - 1000 nos", price: "Rs. 450.00", image: "https://ext.same-assets.com/2358184486/784078873.jpeg" },
                { name: "Economy Matt Visiting Card - 1000 nos", price: "Rs. 475.00", image: "https://ext.same-assets.com/2358184486/505005531.jpeg" },
                { name: "Circle Shape Visiting Card", price: "Rs. 850.00", image: "https://ext.same-assets.com/2358184486/879202176.jpeg" }
              ].map((product) => (
                <Card key={product.name} className="gradient-card border-slate-600 overflow-hidden group hover:scale-105 transition-transform duration-300">
                  <div className="relative h-48">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardHeader>
                    <CardTitle className="text-white text-sm">{product.name}</CardTitle>
                    <CardDescription className="text-blue-300 font-semibold">From {product.price}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                      <Button className="whatsapp-btn w-full text-white">
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Buy on WhatsApp
                      </Button>
                    </a>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Other Services */}
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { name: "Flyers / Leaflets", description: "High-quality promotional materials", image: "https://ext.same-assets.com/2358184486/1475995303.jpeg" },
              { name: "Notebook & Wiro Series", description: "Custom notebooks and binding", image: "https://ext.same-assets.com/2358184486/3525599730.jpeg" },
              { name: "New Year Diaries & Calendars", description: "Personalized calendars and diaries", image: "https://ext.same-assets.com/2358184486/1986776723.jpeg" }
            ].map((service) => (
              <Card key={service.name} className="gradient-card border-slate-600 overflow-hidden group hover:scale-105 transition-transform duration-300">
                <div className="relative h-48">
                  <img
                    src={service.image}
                    alt={service.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="text-white">{service.name}</CardTitle>
                  <CardDescription className="text-slate-300">{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                    <Button className="whatsapp-btn w-full text-white">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Inquire on WhatsApp
                    </Button>
                  </a>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="gradient-section py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              What Our <span className="text-blue-400">Customers Say</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Krishnakumar Subramani",
                review: "Ordered some posters and banners for an awareness event. The service was excellent! The posters and banners were delivered on time. They even took efforts to personally deliver it to our event venue. Fantastic work and efforts!",
                rating: 5
              },
              {
                name: "Sridevi A",
                review: "Best Quality... Good and fast response. Excellent work. Great Solution for all our designing and Printing needs... Highly recommended...",
                rating: 5
              },
              {
                name: "Archana Mani",
                review: "Highly reliable service! Great follow-ups. The quality of printing is outstanding and delivery was prompt. Will definitely use their services again.",
                rating: 5
              }
            ].map((testimonial) => (
              <Card key={testimonial.name} className="gradient-card border-slate-600">
                <CardHeader>
                  <div className="flex items-center space-x-1 mb-2">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={`star-${testimonial.name}-${i}`} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <CardTitle className="text-white">{testimonial.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-300 italic">"{testimonial.review}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gradient-to-b from-slate-900 to-black">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Get In <span className="text-blue-400">Touch</span>
            </h2>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Ready to start your printing project? Contact us today for a quote!
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 max-w-4xl mx-auto">
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white mb-6">Contact Information</h3>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center">
                  <Phone className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-white font-semibold">Phone</p>
                  <p className="text-slate-300">+91 824 848 1143</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center">
                  <MessageCircle className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-white font-semibold">WhatsApp</p>
                  <p className="text-slate-300">+91 824 848 1143</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center">
                  <Mail className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-white font-semibold">Email</p>
                  <p className="text-slate-300">mrbharathyprinters@gmail.com</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-red-500 rounded-lg flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-white font-semibold">Service Area</p>
                  <p className="text-slate-300">Shipping All Over India</p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white mb-6">Quick Actions</h3>

              <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="whatsapp-btn w-full text-white font-semibold py-6">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Start WhatsApp Chat
                </Button>
              </a>

              <a href="tel:+918248481143">
                <Button size="lg" variant="outline" className="w-full border-blue-400 text-blue-300 hover:bg-blue-500/20 py-6">
                  <Phone className="w-5 h-5 mr-2" />
                  Call Now
                </Button>
              </a>

              <a href="mailto:mrbharathyprinters@gmail.com">
                <Button size="lg" variant="outline" className="w-full border-purple-400 text-purple-300 hover:bg-purple-500/20 py-6">
                  <Mail className="w-5 h-5 mr-2" />
                  Send Email
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black border-t border-slate-800 py-12">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                <Printer className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white">Mr. Bharathy Printers</h3>
            </div>
            <p className="text-slate-400 mb-6">
              High-Quality Printing. Affordable Prices. Delivered Across India.
            </p>
            <div className="flex justify-center space-x-6 mb-6">
              <a href="#home" className="text-slate-400 hover:text-blue-400 transition-colors">Home</a>
              <a href="#about" className="text-slate-400 hover:text-blue-400 transition-colors">About</a>
              <a href="#products" className="text-slate-400 hover:text-blue-400 transition-colors">Products</a>
              <a href="#contact" className="text-slate-400 hover:text-blue-400 transition-colors">Contact</a>
            </div>
            <p className="text-slate-500 text-sm">
              © 2025 Mr. Bharathy Printers. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
