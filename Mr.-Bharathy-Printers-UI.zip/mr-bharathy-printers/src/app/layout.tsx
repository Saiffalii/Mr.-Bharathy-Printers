import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import ClientBody from "./ClientBody";

const geist = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Mr. Bharathy Printers - High-Quality Printing Services | Viboodhi Covers, Visiting Cards & More",
  description: "Premium printing services in India. Specializing in Viboodhi covers, visiting cards, flyers, notebooks, and calendars. High-quality printing at affordable prices with pan-India delivery. Contact us on WhatsApp +91 824 848 1143.",
  keywords: [
    "printing services india",
    "viboodhi covers",
    "visiting cards printing",
    "business cards",
    "flyers printing",
    "notebooks printing",
    "calendars printing",
    "religious printing",
    "mr bharathy printers",
    "affordable printing",
    "pan india delivery",
    "perumal viboodhi covers",
    "shivan viboodhi covers",
    "matt visiting cards",
    "gloss visiting cards",
    "circle shape visiting cards"
  ],
  authors: [{ name: "Mr. Bharathy Printers" }],
  creator: "Mr. Bharathy Printers",
  publisher: "Mr. Bharathy Printers",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: "en_IN",
    url: "https://www.mrbharathyprinters.in",
    title: "Mr. Bharathy Printers - High-Quality Printing Services",
    description: "Premium printing services in India. Viboodhi covers, visiting cards, flyers & more. Affordable prices with pan-India delivery.",
    siteName: "Mr. Bharathy Printers",
    images: [
      {
        url: "https://ext.same-assets.com/2358184486/3717697990.jpeg",
        width: 1200,
        height: 630,
        alt: "Mr. Bharathy Printers - Premium Printing Services",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Mr. Bharathy Printers - High-Quality Printing Services",
    description: "Premium printing services in India. Viboodhi covers, visiting cards, flyers & more. Affordable prices with pan-India delivery.",
    images: ["https://ext.same-assets.com/2358184486/3717697990.jpeg"],
  },
  verification: {
    google: "your-google-verification-code",
  },
  alternates: {
    canonical: "https://www.mrbharathyprinters.in",
  },
  category: "Printing Services",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <meta name="theme-color" content="#3b82f6" />
        <meta name="application-name" content="Mr. Bharathy Printers" />
        <meta name="apple-mobile-web-app-title" content="Mr. Bharathy Printers" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />

        {/* Local Business Schema */}
        <script
          type="application/ld+json"
          // biome-ignore lint/security/noDangerouslySetInnerHtml: This is safe structured data for SEO
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              "name": "Mr. Bharathy Printers",
              "description": "Premium printing services in India specializing in Viboodhi covers, visiting cards, flyers, notebooks, and calendars.",
              "url": "https://www.mrbharathyprinters.in",
              "telephone": "+91-824-848-1143",
              "email": "mrbharathyprinters@gmail.com",
              "address": {
                "@type": "PostalAddress",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": "12.9716",
                "longitude": "77.5946"
              },
              "areaServed": {
                "@type": "Country",
                "name": "India"
              },
              "serviceType": "Printing Services",
              "priceRange": "₹199-₹850",
              "paymentAccepted": ["Cash", "Bank Transfer", "UPI"],
              "currenciesAccepted": "INR",
              "openingHours": "Mo-Sa 09:00-18:00",
              "hasOfferCatalog": {
                "@type": "OfferCatalog",
                "name": "Printing Services",
                "itemListElement": [
                  {
                    "@type": "Offer",
                    "itemOffered": {
                      "@type": "Service",
                      "name": "Viboodhi Covers",
                      "description": "Religious Viboodhi covers for Perumal and Shivan"
                    },
                    "price": "199",
                    "priceCurrency": "INR"
                  },
                  {
                    "@type": "Offer",
                    "itemOffered": {
                      "@type": "Service",
                      "name": "Visiting Cards",
                      "description": "Professional visiting cards in various finishes"
                    },
                    "price": "450",
                    "priceCurrency": "INR"
                  }
                ]
              }
            })
          }}
        />
      </head>
      <ClientBody className={`${geist.variable} ${geistMono.variable} antialiased`}>
        {children}
      </ClientBody>
    </html>
  );
}
